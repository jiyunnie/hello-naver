var loc1, loc2, loc3;
var defaultDepth1;

function getMenuInfo(){
	// get location
	loc1 = $('.loc_1').text();
	loc2 = $('.loc_2').text();
	loc3 = $('.loc_3').text();
}

function menuInit(){
	
	getMenuInfo();
	
}

$(function(){
	
	userAgentCheck();

	menuInit();
	
	/*====================================
	 * 배너
	 =====================================*/

	var topBanner = $( '.banner' ),
		topCheck = $( '#top_check' ),
		topBtn = topBanner.find( 'button' );
	
	if ( $.cookie( 'hideBanner' ) == 'true' ) {
		topBanner.css({ height : 0}, 300 );
	}
	
	topBtn.on( 'click', function() {
		if ( topCheck.prop( 'checked' ) ) {
			$.cookie( 'hideBanner', 'true', { expires: 1, path : '/' } );
		} else {
			$.cookie( 'hideBanner', 'true', { path : '/'} );
		}
		topBanner.stop().animate({ height : 0 }, 300 );
	});
	
	/* ���κ��־� */
	(function () {
		var visuals = $( '#visual .visual_wrap > ul' ),
			visualImg = visuals.find( 'li' ),
			visualTimer = 0,
			visualNav = $( '#visual .nav' );
		
		if ( visualImg.length == 1 ) {
			visualToggle.hide();
			visualNav.hide();
			return false;
		}
		
		visuals.data('crt', 0);
		
		var defaultStyle = {
				'margin-top' : 0
			},
			hideStyle = {
				'margin-top' : -518
			},
			readyStyle = {
				'margin-top' : 518
			};
			
		visualImg.each(function () {
			var self = $(this);
			if(!self.hasClass('current')) {
				self.css(readyStyle);
			}
		});
		
		if ( visualImg.length > 1 ) {
			var visualBtns = '';
			visualBtns += '<ul>'
			for( var i = 0, len = visualImg.length; i < len; i++ ){
				visualBtns += '<li><button type="button">visual' + i + '</button></li>';
			}
			visualBtns += '</ul>'
			visualBtns += '<button type="button" class="toggle">���/�Ͻ�����</button>'
			visualNav.append( $( visualBtns) );
		}
		
		var visualNavBtn = $( '#visual .nav li button' );
		visualNavBtn.eq( 0 ).addClass( 'on');
		visualNavBtn.on( 'click', function () {
				var self = $(this),
					newNum = visualNavBtn.index(self),
					crtNum = visuals.data('crt');
				
				if ( newNum != crtNum ) {
					setPosition( crtNum, newNum );

					if ( newNum < crtNum ) {
						slideAction( 'reverse' );
					} else {
						slideAction();
					}

					visualNavBtn.eq( crtNum ).removeClass('on');
					self.addClass('on');
					
					clearInterval( visualTimer );
					visualTimer = 0;
					$( '#visual .toggle' ).addClass( 'off' );
				}
				return false;
		});
		
		function setPosition( crtNum, newNum ) {
			visualImg.eq( crtNum ).removeClass( 'current' )
					
			visualImg.eq( crtNum ).addClass( 'hide' );
			visualImg.eq( newNum ).addClass( 'current' )
			
			visuals.data('crt', newNum);
		}
		
		function slideAction ( dir ) {
			if ( dir ) {
				var hide = readyStyle,
					ready = hideStyle;
			} else {
				var hide = hideStyle,
					ready = readyStyle;
			}

			visualImg.filter( '.hide' ).stop().animate( hide, 600 ).removeClass( 'hide' );
			
			visualImg.filter( '.current' ).css( ready ).stop().animate( defaultStyle, 600 );
		}
		
		function autoSlide() {
			var crtNum = visuals.data('crt'),
				newNum = crtNum + 1;
				
				newNum = newNum > visualImg.length - 1  ? 0 : newNum;
			//visualNavBtn.eq(newNum).trigger('click');
			setPosition( crtNum, newNum );
			slideAction();
			
			visualNavBtn.eq( crtNum ).removeClass('on');
			visualNavBtn.eq( newNum ).addClass('on');
		}
		
		$( '#visual .toggle' ).on( 'click', function() {
			if ( visualTimer ) {
				clearInterval( visualTimer );
				visualTimer = 0;
				$( this ).addClass( 'off' );
			} else {
				visualTimer = setInterval(autoSlide, 5500);
				$( this ).removeClass( 'off' );
			}
		});
		
		visualTimer = setInterval(autoSlide, 5500);
	})();
	
	$( window ).on({
		'load' : userAgentCheck,
		'resize' : userAgentCheck
	});
	
	function checkResize() {
		var crtWidth = $( window ).width();
		if ( crtWidth < 1200 ) {
			var tx = ( 1800 - crtWidth ) / 2 + 20;
			if ( tx > 415 ) { tx = 415 }
			$( '#visual .nav' ).css({ 'right' : tx });
			$( '.quick_menu' ).hide();
		} else {
			$( '#visual .nav' ).css({ 'right' : 322 });
			$( '.quick_menu' ).show();
		}
	}

	function userAgentCheck(){
		var filter = "win16|win32|win64|mac|macintel";
		if( navigator.platform ){
			if( filter.indexOf( navigator.platform.toLowerCase() ) < 0 ){
				$('.quick_menu').css({'display': 'none'});
			} else {
				checkResize();
			}
		}
	}
	
	var mainCont = $( '#contents .main_contents .section' ),
		mainContList = $( '#contents .main_contents .section .hover' );
	mainCont.on({
		'mouseenter' : function() {
			$( this ).find( '.hover' ).stop().animate({ 'opacity' : 1 });
		},
		'mouseleave' : function() {
			$( this ).find( '.hover' ).stop().animate({ 'opacity' : 0 });
		}
	});
	mainContList.css({ 'opacity' : 0 });
	
		
	var filter2 = "win16|win32|win64|mac|macintel";
	var ua = window.navigator.userAgent;
	var msie = ua.indexOf("MSIE");
	if( navigator.platform ){
		if( filter2.indexOf( navigator.platform.toLowerCase() ) < 0 ){
			return false;
		} else {
			
			if ( navigator.userAgent.indexOf('Trident/7.0') > -1) {
				return false;
			} else if ( msie < 0 ) {
				
				$( '#header .btn_login' )[0].onclick = null;
				$( '#header .btn_login' ).on( 'click', function() {
					alert( '�����Ͻ� ����� ���ͳ��ͽ��÷η� ������ �� ���� �Ұ��� ����Դϴ�.\n��뿡 ������ ��� �˼��մϴ�.' );
					return false;
				});
				
				if ( $( '.lookup .btn_find a' ).length > 0 ) {
					$( '.lookup .btn_find a' )[0].onclick = null;
					$( '.lookup .btn_find a' ).on( 'click', function() {
						alert( '�����Ͻ� ����� ���ͳ��ͽ��÷η� ������ �� ���� �Ұ��� ����Դϴ�.\n��뿡 ������ ��� �˼��մϴ�.' );
						return false;
					});
				}
			}
			
		}
	}
	
});