/*
    특정 극장의 별도 URL 관리가 필요한 Json 관리 페이지 입니다.
    메뉴 극장 에서 사용되는 js
    서울 지역 CINE de CHEF 압구정
    부산/경남 CINE de CHEF 센텀

*/
//document.domain = "cgv.co.kr";

var extraTheaterData = [
	{ 'code': 'P001', 'link': '/theaters/special/show-times.aspx?regioncode=103&theatercode=0040' },
    { 'code': 'P004', 'link': '/theaters/special/show-times.aspx?regioncode=103&theatercode=0089' },
    { 'code': 'K049', 'link': '/theaters/special/show-times.aspx?regioncode=CK&theatercode=0049' }
];