package controller.mycgv;

import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import mybatis.setting.inquiryDAO;
import mybatis.setting.inquiryDTO;
import mybatis.setting.memberBean;
import mybatis.setting.memberDAO;
import mybatis.setting.memberDTO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class ProfileController {
	private memberDAO memDao;
	
	public void setMemDao(memberDAO memDao) {
		this.memDao = memDao;
	}
	private inquiryDAO inqDao;
	public void setInqDao(inquiryDAO inqDao) {
		this.inqDao = inqDao;
	}
	
	

	//mycgv
	@RequestMapping("mycgv.do")
	public ModelAndView mycgv(HttpSession session)
	{
		
		ModelAndView view=new ModelAndView();
		String id=(String)session.getAttribute("id");
		memberDTO dto =  memDao.getData(id);
		
		
		
		view.addObject("dto",dto);
		view.setViewName("/mypage/mycgv");
		return view;
		
	}
	
	
	//예매
	@RequestMapping("myreserve.do")
	public ModelAndView reserve()
	{
		ModelAndView view=new ModelAndView();
		
		view.setViewName("/mypage/myreserve");
		return view;
		
	}
	
	//회원정보
	@RequestMapping("password.do")
	public ModelAndView password()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("/mypage/password");
		return view;
	}
	
	@RequestMapping("myinfo.do")
	public ModelAndView myinfo()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("/mypage/myinfo");
		return view;
		
	}
	
	
	
	
	@RequestMapping("myprofile.do")
	public ModelAndView myprofile()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("/mypage/myprofile");
		return view;
		
	}
	
	@RequestMapping("qna.do")
	public ModelAndView qna(
			@RequestParam("qid") String qid)
	{
		ModelAndView view=new ModelAndView();
		List<inquiryDTO> list= inqDao.getmylist(qid);
		
		
		view.addObject("totalcount", list.size());
		view.addObject("list", list);
		view.setViewName("/mypage/qna");
		return view;
	}
	
	@RequestMapping("result.do")
	public ModelAndView result(
			@RequestParam("qid") String qid,
			@RequestParam("ref") String ref
			)
	{
		
		ModelAndView view = new ModelAndView();
		List<inquiryDTO> list=inqDao.getMyanswer(qid, ref);
		
		view.addObject("list", list);
		view.setViewName("/mypage/result");
		return view;
	}
	
	@RequestMapping("inquiry.do")
	public ModelAndView inquiry(
			@RequestParam("id")String id)
	{
		ModelAndView view=new ModelAndView();
		
		memberDTO dto=memDao.getData(id);
		memberBean b=new memberBean();
		
		StringTokenizer st=new StringTokenizer(dto.getPhone(),"-");
		b.setPhone(st.nextToken());
		b.setPhone_1(st.nextToken());
		b.setPhone_2(st.nextToken());
		
		StringTokenizer et=new StringTokenizer(dto.getEmail(),"@");
		b.setEmail1(et.nextToken());
		b.setEmail2(et.nextToken());
		
		view.addObject("b", b);
		view.addObject("dto",dto);
		view.setViewName("/mypage/inquiry");
		return view;
	}
	
	@RequestMapping(value="qnawrite.do",method = RequestMethod.POST)
	public ModelAndView qnawrite(
			inquiryDTO dto,
			@RequestParam("realsave") MultipartFile realsave,
			HttpServletRequest request
			
			)
	{ 
		ModelAndView view=new ModelAndView();
		String path=request.getSession().getServletContext().getRealPath("/uploadimage");
		System.out.println("path:"+path);
		String addfile=realsave.getOriginalFilename();
		System.out.println(addfile);
		FileWriter writer=new FileWriter();
		writer.writeFile(realsave, path, realsave.getOriginalFilename());
		dto.setAddfile(addfile);
		dto.setAdminid("0");
		dto.setDisposal("미처리");
		inqDao.insertInquiry(dto);	
		
		
		
		view.setViewName("/mypage/inqsuccess");
		return view;
	}
	
	
	

	@RequestMapping("inqsuccess.do")
	public String inqsuccess()
	{
		
		return "/mypage/inqsuccess";
	}
	
	
	@RequestMapping("lost.do")
	public ModelAndView lost()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("/mypage/lost");
		return view;
		
	}
	
}
	
	

