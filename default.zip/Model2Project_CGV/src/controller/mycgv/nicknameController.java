package controller.mycgv;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import mybatis.setting.ZipcodeDTO;
import mybatis.setting.memberDAO;
import mybatis.setting.memberDTO;

@Controller
public class nicknameController {

	private memberDAO memDao;
	
	public void setMemDao(memberDAO memDao) {
		this.memDao = memDao;
	}
	
	@RequestMapping("nicknamesearch.do")
	public ModelAndView nicknameform(HttpServletRequest request)
	{
		ModelAndView view=new ModelAndView();
	
	
		view.addObject("path", request.getContextPath());
		view.setViewName("/pop/mypage/PopNickname");
		return view;
	}


	
	
}
