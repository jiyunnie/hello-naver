package controller.customer;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ReserveController {

	@RequestMapping("/customer/reserve.do")
	public String gocustomer()
	{
		return "/customer/reserve";
	}
}
