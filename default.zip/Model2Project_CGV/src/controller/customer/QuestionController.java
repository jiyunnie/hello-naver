package controller.customer;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import mybatis.setting.questionDAO;
import mybatis.setting.questionDTO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class QuestionController {
	
	private questionDAO qDao;
	
	public void setqDao(questionDAO qDao) {
		this.qDao = qDao;
	}
	
	@RequestMapping("/customer/question.do")
	public ModelAndView qlist(HttpServletRequest request,
			@RequestParam(value="pageNum",defaultValue="1") String pageNum)
	{
		ModelAndView view=new ModelAndView();
		//페이징 처리
		int totalCount=0;//총 게시물 갯수
		int perPage=5;//한페이지당 출력할 글갯수
		int perBlock=5;//한블럭당 출력할 페이지수
		int totalPage;//총 페이지수
		int totalBlock;//총 블럭수
		int currentPage;//현재 페이지번호
		int startNum;//각페이지에 출력될 시작번호
		int endNum;//각페이지에 출력될 마지막번호
		int startPage;//각블럭에 출력될 페이지시작번호
		int endPage;//각블럭에 출력될 페이지마지막번호
		int no;//출력할 시작번호		
		
		List<questionDTO> list=null;
		
		currentPage=Integer.parseInt(pageNum);
	    totalCount=qDao.getTotalCount();
		
		totalPage=totalCount/perPage+(totalCount%perPage>0?1:0);
		totalBlock=totalPage/perBlock+(totalPage%perBlock>0?1:0);
		
		startNum=(currentPage-1)*perPage+1;//1,4,7
		endNum=startNum+perPage-1;//3,6,9...
		if(endNum>totalCount)
			endNum=totalCount;
		
		startPage=(currentPage-1)/perPage*perPage+1;//1,4,7
		endPage=startPage+perBlock-1;
		if(endPage>totalPage)
			endPage=totalPage;
		
		//게시물앞에 출력되는 시작번호
		no=totalCount-startNum+1;//10,7,4...
		//데이타 불러오기
	    list=qDao.getList(startNum, endNum);
	    //공지 데이타 불러오기
	    /*List<questionDTO> qlist=boardDAO.getGongjiList();*/
	    
		
		//review 에 데이타를 담기
		view.addObject("totalCount",totalCount );
		view.addObject("perPage",perPage );
		view.addObject("perBlock",perBlock );
		view.addObject("totalPage",totalPage );
		view.addObject("totalBlock",totalBlock );
		view.addObject("currentPage",currentPage );
		view.addObject("startPage",startPage );
		view.addObject("endPage", endPage);
		view.addObject("no",no );
		view.addObject("list",list );
		/*view.addObject("glist",glist);*/
		
		view.addObject("path",request.getContextPath());
		view.setViewName("/customer/question");
		return view;
	}
	

}
