package controller.customer;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LostController {

	@RequestMapping("/customer/lost.do")
	public String gocustomer()
	{
		return "/customer/lost";
	}
}
