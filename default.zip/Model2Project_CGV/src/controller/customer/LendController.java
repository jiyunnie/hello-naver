package controller.customer;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LendController {

	@RequestMapping("/customer/lend.do")
	public String gocustomer()
	{
		return "/customer/lend";
	}
}
