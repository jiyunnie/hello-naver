package controller.customer;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CMController {
	
	@RequestMapping("/customer/customer.do")
	public String gocustomer()
	{
		return "/customer/container";
	}
	

}
