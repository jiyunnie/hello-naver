package controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import mybatis.setting.questionDAO;
import mybatis.setting.questionDTO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;




@Controller
public class questionController {

	
	private questionDAO qDao;
	public void setqDao(questionDAO qDao) {
		this.qDao = qDao;
	}
	
	
	@RequestMapping("question.do")
	public ModelAndView question(HttpServletRequest request,
			@RequestParam(value="pageNum",defaultValue="1") String pageNum)
	{
		ModelAndView view = new ModelAndView();
		
		
		List<questionDTO> list = qDao.getlist();
		
		view.addObject("list", list);
		view.addObject("totalCount",list.size());		
		view.setViewName("/admin/question/question");
		
		return view;
	}
	
	
	@RequestMapping("writeform.do")
	public ModelAndView form(HttpServletRequest request, HttpSession session)
	{
		ModelAndView view = new ModelAndView();
		
		view.setViewName("/admin/question/writeform");
		
		return view;
		
	}
	
	
	@RequestMapping(value="insert.do",method=RequestMethod.POST)
	public ModelAndView insert(@RequestParam("adminid") String adminid, @RequestParam("adminpass") String adminpass, questionDTO dto,HttpSession session)
	{
		ModelAndView view = new ModelAndView();
		
		qDao.insertquestion(dto);
		view.addObject("adminpass", adminpass);
		
		view.setViewName("redirect:question.do");
		
		return view;
	}
	
	
	
	@RequestMapping("updateform.do")
	public ModelAndView updateform(@RequestParam("num") String num, 
			HttpServletRequest request)
	{
		ModelAndView view = new ModelAndView();
		questionDTO dto=qDao.getData(num);
		
		view.addObject("dto", dto);
		view.addObject("path", request.getContextPath());
		view.setViewName("/admin/question/updateform");
		
		return view;
		
		
	}
	
	
	
	
	@RequestMapping(value="update.do",method=RequestMethod.POST)
	public String update(questionDTO dto)
	{
		qDao.updateBoard(dto);
		return "redirect:question.do";
	}
	
	
	
	
	
	@RequestMapping("delete.do")
	public String delete(@RequestParam("num") String num)
		{
	
				qDao.deleteBoard(num);
				
				return "redirect:question.do";

			
		}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
}
