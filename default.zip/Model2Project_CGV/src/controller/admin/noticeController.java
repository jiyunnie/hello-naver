package controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import mybatis.setting.noticeDAO;
import mybatis.setting.noticeDTO;
import mybatis.setting.questionDTO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class noticeController {

	private noticeDAO nDao;
	
	public void setnDao(noticeDAO nDao) {
		this.nDao = nDao;
	}
	
	
	@RequestMapping("notice.do")
	public ModelAndView question(HttpServletRequest request)
	{
		ModelAndView view = new ModelAndView();
		
		
		List<noticeDTO> list = nDao.getlist();
		
		view.addObject("list", list);
		view.addObject("totalCount",list.size());		
		view.setViewName("/admin/notice/notice");
		
		return view;
	}
	
	
	@RequestMapping("nwriteform.do")
	public ModelAndView form(HttpServletRequest request, HttpSession session)
	{
		ModelAndView view = new ModelAndView();
		
		view.setViewName("/admin/notice/writeform");
		
		return view;
		
	}

	
	@RequestMapping(value="ninsert.do",method=RequestMethod.POST)
	public ModelAndView insert(@RequestParam("adminid") String adminid,noticeDTO dto,HttpSession session)
	{
		ModelAndView view = new ModelAndView();
		
		nDao.insertquestion(dto);
		
		view.setViewName("redirect:notice.do");
		
		return view;
	}
	
	

	@RequestMapping("nupdateform.do")
	public ModelAndView updateform(@RequestParam("num") String num, 
			HttpServletRequest request)
	{
		ModelAndView view = new ModelAndView();
		noticeDTO dto=nDao.getData(num);
		
		view.addObject("dto", dto);
		view.addObject("path", request.getContextPath());
		view.setViewName("/admin/notice/updateform");
		
		return view;
		
		
	}
	
	
	
	
	@RequestMapping(value="nupdate.do",method=RequestMethod.POST)
	public String update(noticeDTO dto)
	{
		nDao.updateBoard(dto);
		return "redirect:notice.do";
	}
	

	
	@RequestMapping("ndelete.do")
	public String delete(@RequestParam("num") String num)
		{
	
				nDao.deleteBoard(num);
				
				return "redirect:notice.do";

			
		}
	
	
	
	
}
