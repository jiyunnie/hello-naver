package controller.admin;


import javax.servlet.http.HttpSession;

import mybatis.setting.adminDAO;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class loginController {

   private adminDAO adDao;
   public void setAdDao(adminDAO adDao) {
	this.adDao = adDao;
   }

  @RequestMapping(value="admin/loginproc.do", method=RequestMethod.POST)
      public String loginproc(HttpSession session,
            @RequestParam("adminid") String adminid, @RequestParam("adminpass") String adminpass)
            {
	  			boolean sw=adDao.adminLogin(adminid, adminpass);
	  			if(sw)
               {                  
	  		      session.setAttribute("adminpass", adminpass);
                  session.setAttribute("adminlogin","yes");
                  session.setAttribute("adminid", adminid); 
                  return "/adminmain/main";
               }  
	  			else
                  return "/passfail/passfail";
      
            }   
  
   /*
   @RequestMapping("logout.do")
      public String logout(HttpSession session)
      {
         session.removeAttribute("loginok");
         return "redirect:main.do";
      }*/
      
   
  
  
  
  
}