package controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import mybatis.setting.movieDAO;
import mybatis.setting.movieDTO;
import mybatis.setting.noticeDTO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MovieController {

	private movieDAO mvDao;
	
	public void setMvDao(movieDAO mvDao) {
		this.mvDao = mvDao;
	}
	
	@RequestMapping("adminmovie.do")
	public ModelAndView mvupdate()
	{
		ModelAndView view = new ModelAndView();

		List<movieDTO> list= mvDao.getAllDatas();
		
		view.addObject("list", list);
		view.addObject("totalCount",list.size());
		view.setViewName("/admin/movie/movie");
		return view;
	}
	
	@RequestMapping("mvwriteform.do")
	public ModelAndView movieupdatego(HttpServletRequest request, HttpSession session)
	{		
		ModelAndView view=new ModelAndView();
		
		view.setViewName("/admin/movie/writeform");
		
		return view;
	}
	
	@RequestMapping(value="mvinsert.do",method=RequestMethod.POST)
	public ModelAndView insert(movieDTO dto,HttpSession session)
	{
		ModelAndView view = new ModelAndView();
		
		mvDao.insertmovie(dto);
		
		view.setViewName("redirect:adminmovie.do");
		
		return view;
	}
	
}
