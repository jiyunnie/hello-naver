package controller.admin;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;




import mybatis.setting.inquiryDAO;
import mybatis.setting.inquiryDTO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class inquiryController {

	private inquiryDAO iDao;
	
	public void setiDao(inquiryDAO iDao) {
		this.iDao = iDao;
	}
	
	@RequestMapping("/admin/inquiry.do")
	public ModelAndView inquiry(HttpServletRequest request,
			@RequestParam(value="pageNum",defaultValue="1") String pageNum)
	{
		ModelAndView view=new ModelAndView();
		//페이징 처리
		
		int totalCount=0;//총 게시물 갯수
		int perPage=10;//한 페이지당 출력할 글갯수
		int perBlock=5;//한 블럭당 출력할 페이지 수
		int totalPage;//총 페이지 수
		int totalBlock;//총 블럭수
		int currentPage;//현재 페이지 번호
		int startNum;//각 페이지에 출력될 시작번호
		int endNum;//각 페이지에 출력될 마지막 번호
		int startPage;//각 블럭에 출력될 페이지 시작번호
		int endPage;//각 블럭에 출력될 페이지 마지막 번호
		int no;//출력할 시작번호
		
	
		
		List<inquiryDTO> list=null;
		
		
		currentPage=Integer.parseInt(pageNum);
		totalCount=iDao.getTotalCount();
		
		
		totalPage=totalCount/perPage+(totalCount%perPage>0?1:0);
		totalBlock=totalPage/perBlock+(totalPage%perBlock>0?1:0);
		
		startNum=(currentPage-1)*perPage+1;//1,4,7
		endNum=startNum+perPage-1;//3,6,9...
		if(endNum>totalCount)
			endNum=totalCount;
		
		startPage=(currentPage-1)/perPage*perPage+1;//1,4,7
		endPage=startPage+perBlock-1;
		if(endPage>totalPage)
			endPage=totalPage;
		
		
		//게시물앞에 출력되는 시작번호
		no=totalCount-startNum+1;//10,7,4...
		
		//데이타 불러오기
		list=iDao.getlist(startNum, endNum);
		
		
		
		//request에 데이타 담기
		view.addObject("totalCount",totalCount );
		view.addObject("perPage", perPage);
		view.addObject("perBlock", perBlock);
		view.addObject("totalPage",totalPage );
		view.addObject("totalBlock", totalBlock);
		view.addObject("currentPage", currentPage);
		view.addObject("startPage",startPage);
		view.addObject("endPage",endPage );
		view.addObject("no",no );
		view.addObject("list", list);
		

		view.addObject("path", request.getContextPath());
		view.setViewName("/admin/inquiry/inquiry");
		
		return view;
	}
	
	
	
	@RequestMapping("content.do")
	public ModelAndView form(HttpServletRequest request, HttpSession session,
			@RequestParam("num") String num)
	{
		ModelAndView view = new ModelAndView();
		
		inquiryDTO dto=iDao.getData(num);
		
		view.addObject("dto", dto);
		view.addObject("realpath", request.getSession().getServletContext().getRealPath("/uploadimage"));
		
		view.setViewName("/admin/inquiry/content");
		
		return view;
		
	}
	
	
	@RequestMapping("answerform.do")
	public ModelAndView answerform(HttpServletRequest request, HttpSession session,
			@RequestParam(value="num", defaultValue="0") String num)
	{
		ModelAndView view = new ModelAndView();
		inquiryDTO dto=iDao.getData(num);
		
		view.addObject("dto", dto);
		view.addObject("path", request.getContextPath());
		
		view.setViewName("/admin/inquiry/answer");
		
		return view;
	}
	
	@RequestMapping("answer.do")
	public ModelAndView answer(
			@RequestParam("num") String num,
			@RequestParam("answer") String answer,
			HttpSession session,
			inquiryDTO dto)
	{
		ModelAndView view = new ModelAndView();
		//System.out.println("num="+num);
		//System.out.println(answer);		
		
		//System.out.println(session.getAttribute("adminid"));
		//System.out.println(dto.getHp());
		dto.setContent(answer);
			
		dto.setDisposal("처리완료");
		dto.setAdminid((String)session.getAttribute("adminid"));
		
		iDao.insertInquiry(dto);
		view.setViewName("redirect:admin/inquiry.do");
		return view;
	}		
	
	
	
	
	
	
	
	
	
	
	
}



