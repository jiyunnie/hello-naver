package controller.vip;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ServeseController {

	@RequestMapping("servese.do")
	public String gocustomer()
	{
		return "vip.tiles";
	}
	
	
}
