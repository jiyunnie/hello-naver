package controller.vip;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class VIPCouponeController {

	@RequestMapping("vipcoupone.do")
	public String govip()
	{
		return "/vip/vipcoupone";
	}

}
