package controller.vip;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class VIPController {
	
	@RequestMapping("vip.do")
	public String govip()
	{
		return "vip.tiles";
	}
	

}
