package controller.footermenu;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RuleController {

	@RequestMapping("rule.do")
	public ModelAndView rule()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("/footer/rule");
		return view;
	}
	
	@RequestMapping("privacy.do")
	public ModelAndView privacy()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("/footer/privacy");
		return view;
	}
	
	@RequestMapping("organized.do")
	public ModelAndView organized()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("/footer/organized");
		return view;
	}
	
	/*@RequestMapping("introduce.do")
	public ModelAndView introduce()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("/corp/introduce");
		return view;
	}
	*/

}
