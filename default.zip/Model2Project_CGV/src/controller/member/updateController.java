package controller.member;

import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import mybatis.setting.memberBean;
import mybatis.setting.memberDAO;
import mybatis.setting.memberDTO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class updateController {
	
	private memberDAO memDao;
	
	public void setMemDao(memberDAO memDao) {
		this.memDao = memDao;
	}

	@RequestMapping("/member/updateform.do")
	public ModelAndView updateform(@RequestParam("id") String id,
			HttpServletRequest request)
	{
		ModelAndView view=new ModelAndView();
		memberDTO dto=memDao.getData(id);
		memberBean b=new memberBean();
		
		b.setPostcode1(dto.getPostcode().substring(0,3));
		b.setPostcode2(dto.getPostcode().substring(4));
	
		StringTokenizer st=new StringTokenizer(dto.getCall(),"-");
		b.setCall(st.nextToken());
		b.setCall_1(st.nextToken());
		b.setCall_2(st.nextToken());
				
		StringTokenizer pt=new StringTokenizer(dto.getPhone(),"-");
		b.setPhone(pt.nextToken());
		b.setPhone_1(pt.nextToken());
		b.setPhone_2(pt.nextToken());
				
		StringTokenizer et=new StringTokenizer(dto.getEmail(),"@");
		b.setEmail1(et.nextToken());
		b.setEmail2(et.nextToken());
		
		
		view.addObject("dto", dto);
		view.addObject("b", b);
		view.addObject("path", request);
		view.setViewName("/member/updateform");
		return view;
	}
	
	@RequestMapping(value="/member/update.do",method=RequestMethod.POST)
	public String update(memberDTO dto,memberBean bean,@RequestParam("num") String num)
	{
		dto.setNum(num);
		dto.setPostcode(bean.getPostcode1()+"-"+bean.getPostcode2());
		dto.setCall(bean.getCall()+"-"+bean.getCall_1()+"-"+bean.getCall_2());
		dto.setPhone(bean.getPhone()+"-"+bean.getPhone_1()+"-"+bean.getPhone_2());
		dto.setEmail(bean.getEmail1()+"@"+bean.getEmail2());
		memDao.updateMember(dto);
		return "redirect:../main.do";
	}
	
	
}
