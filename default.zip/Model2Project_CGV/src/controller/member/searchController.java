package controller.member;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import mybatis.setting.ZipcodeDTO;
import mybatis.setting.memberDAO;
import mybatis.setting.memberDTO;

@Controller
public class searchController {

	private memberDAO memDao;
	
	public void setMemDao(memberDAO memDao) {
		this.memDao = memDao;
	}
	
	@RequestMapping("/member/idsearch.do")
	public ModelAndView idform(HttpServletRequest request)
	{
		ModelAndView view=new ModelAndView();
	
	
		view.addObject("path", request.getContextPath());
		view.setViewName("/pop/layout/member/PopId");
		return view;
	}

	
	@RequestMapping("/member/action.do")
	public ModelAndView id(@RequestParam("id")String id,
			HttpServletRequest request)
	{
		ModelAndView view=new ModelAndView();
		boolean sw=memDao.isSearchId(id);
		view.addObject("id", id);
		view.addObject("path", request);
		view.setViewName("/member/memberform");
		
		return view;
	}
	
	@RequestMapping("/member/postsearch.do")
	public String postform()
	{
		return "/pop/layout/member/PopPost";
	}
	
	@RequestMapping(value="/member/postresult.do",method=RequestMethod.POST)
	public ModelAndView searchpost(@RequestParam("dong") String dong)
	{
		ModelAndView view=new ModelAndView();		
		List<ZipcodeDTO> list=memDao.getAddress(dong);
		
		view.addObject("list",list);
		view.addObject("count", list.size());
		view.setViewName("/pop/layout/member/PopPostResult");
		return view;
	}
	
	
}
