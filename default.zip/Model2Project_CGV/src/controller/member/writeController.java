package controller.member;

import javax.servlet.http.HttpServletRequest;

import mybatis.setting.memberBean;
import mybatis.setting.memberDAO;
import mybatis.setting.memberDTO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class writeController {
	
	private memberDAO memDao;
	
	public void setMemDao(memberDAO memDao) {
		this.memDao = memDao;
	}

	@RequestMapping("/member/form.do")
	public ModelAndView wirteform(HttpServletRequest request)
	{
		ModelAndView view=new ModelAndView();
		view.addObject("path", request);
		view.setViewName("/member/memberform");
		return view;
	}
	
	
	@RequestMapping(value="/member/insert.do",method=RequestMethod.POST)
	public ModelAndView insert(memberBean b,memberDTO dto,HttpServletRequest request)
	{
		ModelAndView view=new ModelAndView();
		dto.setPostcode(b.getPostcode1()+"-"+b.getPostcode2());
		dto.setCall(b.getCall()+"-"+b.getCall_1()+"-"+b.getCall_2());
		dto.setPhone(b.getPhone()+"-"+b.getPhone_1()+"-"+b.getPhone_2());
		dto.setEmail(b.getEmail1()+"@"+b.getEmail2());
		
		memDao.insertMember(dto);
		view.addObject("name", b.getName());
		view.addObject("path", request.getContextPath());
		view.setViewName("/member/success");
		
		
		return view;
	}
	
}
