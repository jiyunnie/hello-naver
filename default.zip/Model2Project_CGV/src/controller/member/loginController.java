package controller.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import mybatis.setting.memberDAO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class loginController {

   private memberDAO memDao;
   public void setMemDao(memberDAO memDao) {
      this.memDao = memDao;
   }
   
   
   
   @RequestMapping("loginform.do")
   public String loginform()
   {
      return "/member/loginform";
   }
   
   @RequestMapping("login.do")
   public ModelAndView login(HttpSession session, HttpServletRequest request)
   {
      ModelAndView view = new ModelAndView();
      
      String loginok=(String)session.getAttribute("loginok");
       String id=(String)session.getAttribute("id");
      
      
      view.addObject("path", request.getContextPath());
      
      
         String name=memDao.getName(id);
         view.addObject("name", name);
         view.setViewName("main.tiles");       
   
      return view;
   }
   
   

   
   @RequestMapping(value="loginproc.do", method=RequestMethod.POST)
      public String loginproc(HttpSession session,
            @RequestParam("id") String id, @RequestParam("password") String password)
            {
               boolean sw=memDao.isLogin(id, password);
               if(sw)
               {                  
                  session.setAttribute("loginok","yes");
                  session.setAttribute("id", id);   
                  session.setAttribute("idok", id);
                 
               }
               
               if(sw)
         
                  return "redirect:login.do";
               else
                  return "/member/passfail";
      
            }   
      
   

   
   
   @RequestMapping("logout.do")
      public String logout(HttpSession session)
      {
         session.removeAttribute("loginok");
         return "redirect:main.do";
      }
      
   
}