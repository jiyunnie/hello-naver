package controller.main;



import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MovieController {

   @RequestMapping("movie.do")
   public ModelAndView movie(HttpServletRequest request)
   {
      ModelAndView view = new ModelAndView();
      
      view.addObject("path", request.getContextPath());
      view.setViewName("/main/layout/menu/movie");
      return view;
   }
}