package mybatis.setting;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;


public class reserveDAO extends SqlSessionDaoSupport{

   
   public int getTotalCount()
   {
      int n=getSqlSession().selectOne("countOfInquiry");
      return n;
   }
   
 
   public List<reserveDTO> getlist(int startNum,int endNum)
   {
      
      HashMap<String, Integer> map=new HashMap<String,Integer>();
      map.put("start", startNum);
      map.put("end", endNum);
      List<reserveDTO> list=getSqlSession().selectList("listOfReserve", map);
      return list;
   }
   
   
   
   
   
   public List<reserveDTO> getmylist(String qid)
   {
      
      
      List<reserveDTO> list=getSqlSession().selectList("mylistOfReserve",qid);
      return list;
   }

   
   public reserveDTO getData(String num)
    {
      reserveDTO dto=getSqlSession().selectOne("onedataOfReserve", num);
       return dto;
    }
   
   
   
   
  public List<reserveDTO> getMyanswer(String qid, String ref)
  {
	  HashMap<String, String>map=new HashMap<String, String>();
	  map.put("qid", qid);
	  map.put("ref", ref);
	 List<reserveDTO> list=getSqlSession().selectList("myanswerOfReserve", map);
	  return list;
  }
   
   
   
   public void updateRestep(int ref,int re_step)
   {
      HashMap<String, Integer>map=new HashMap<String,Integer>();
      map.put("ref", ref);
      map.put("re_step", re_step);
      getSqlSession().update("updateRestepOfInquiry",map);
   }
   
    public void insertReserve(reserveDTO dto)
    {
       
      
       int num=dto.getNum();
       int ref=dto.getRef();
       int re_step=dto.getRe_step();
       int re_level=dto.getRe_level();
       if(num!=0)//답변글인 경우
       {
          updateRestep(ref, re_step);
          re_step=re_step+1;
          re_level=re_level+1;
         
          dto.setRe_step(re_step);
          dto.setRe_level(re_level);
          getSqlSession().insert("insertOfReserve", dto);
          getSqlSession().update("updatedisposalOfInquiry", ref);
         // getSqlSession().update("",)
       }else//새글인 경우
       {
          ref=getSqlSession().selectOne("maxNumOfInquiry");
          ref+=1;
          dto.setRef(ref);
          getSqlSession().insert("insertOfInquiry", dto);
       }
       
    }

}