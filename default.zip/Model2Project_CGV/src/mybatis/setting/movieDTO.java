package mybatis.setting;

import java.sql.Timestamp;

public class movieDTO {
  private int movie_no;
  private String movie_name;
  private String genre;
  private String allow_age;
  private String runningtime;
  private String starday;
  private String director;
  private String cast;
  private String film_company;
  private String Synopsis;
public int getMovie_no() {
	return movie_no;
}
public void setMovie_no(int movie_no) {
	this.movie_no = movie_no;
}
public String getMovie_name() {
	return movie_name;
}
public void setMovie_name(String movie_name) {
	this.movie_name = movie_name;
}
public String getGenre() {
	return genre;
}
public void setGenre(String genre) {
	this.genre = genre;
}
public String getAllow_age() {
	return allow_age;
}
public void setAllow_age(String allow_age) {
	this.allow_age = allow_age;
}
public String getRunningtime() {
	return runningtime;
}
public void setRunningtime(String runningtime) {
	this.runningtime = runningtime;
}
public String getStarday() {
	return starday;
}
public void setStarday(String starday) {
	this.starday = starday;
}
public String getDirector() {
	return director;
}
public void setDirector(String director) {
	this.director = director;
}
public String getCast() {
	return cast;
}
public void setCast(String cast) {
	this.cast = cast;
}
public String getFilm_company() {
	return film_company;
}
public void setFilm_company(String film_company) {
	this.film_company = film_company;
}
public String getSynopsis() {
	return Synopsis;
}
public void setSynopsis(String synopsis) {
	Synopsis = synopsis;
}


  
}
