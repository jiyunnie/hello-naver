package mybatis.setting;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;


public class inquiryDAO extends SqlSessionDaoSupport{

   
   public int getTotalCount()
   {
      int n=getSqlSession().selectOne("countOfInquiry");
      return n;
   }
   
 
   public List<inquiryDTO> getlist(int startNum,int endNum)
   {
      
      HashMap<String, Integer> map=new HashMap<String,Integer>();
      map.put("start", startNum);
      map.put("end", endNum);
      List<inquiryDTO> list=getSqlSession().selectList("listOfInquiry", map);
      return list;
   }
   
   
   
   
   
   public List<inquiryDTO> getmylist(String qid)
   {
      
      
      List<inquiryDTO> list=getSqlSession().selectList("mylistOfInquiry",qid);
      return list;
   }

   
   public inquiryDTO getData(String num)
    {
      inquiryDTO dto=getSqlSession().selectOne("onedataOfInquiry", num);
       return dto;
    }
   
   
   
   
  public List<inquiryDTO> getMyanswer(String qid, String ref)
  {
	  HashMap<String, String>map=new HashMap<String, String>();
	  map.put("qid", qid);
	  map.put("ref", ref);
	 List<inquiryDTO> list=getSqlSession().selectList("myanswerOfInquiry", map);
	  return list;
  }
   
   
   
   public void updateRestep(int ref,int re_step)
   {
      HashMap<String, Integer>map=new HashMap<String,Integer>();
      map.put("ref", ref);
      map.put("re_step", re_step);
      getSqlSession().update("updateRestepOfInquiry",map);
   }
   
    public void insertInquiry(inquiryDTO dto)
    {
       
      
       int num=dto.getNum();
       int ref=dto.getRef();
       int re_step=dto.getRe_step();
       int re_level=dto.getRe_level();
       if(num!=0)//답변글인 경우
       {
          updateRestep(ref, re_step);
          re_step=re_step+1;
          re_level=re_level+1;
         
          dto.setRe_step(re_step);
          dto.setRe_level(re_level);
          getSqlSession().insert("insertOfInquiry", dto);
          getSqlSession().update("updatedisposalOfInquiry", ref);
         // getSqlSession().update("",)
       }else//새글인 경우
       {
          ref=getSqlSession().selectOne("maxNumOfInquiry");
          ref+=1;
          dto.setRef(ref);
          getSqlSession().insert("insertOfInquiry", dto);
       }
       
    }

}