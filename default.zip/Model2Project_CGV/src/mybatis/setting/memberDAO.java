package mybatis.setting;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;




import mybatis.setting.memberDTO;

public class memberDAO extends SqlSessionDaoSupport{

	public boolean isSearchId(String id)
	{
		int n=getSqlSession().selectOne("searchIdOfMember", id);
		return n==1?true:false;		
	}
	
	//로그인
	public boolean isLogin(String id,String password)
	   {
	      HashMap<String, String>map=new HashMap<String, String>();
	      map.put("id", id);
	      map.put("password", password);
	      int n=getSqlSession().selectOne("loginSuccess", map);
	      
	      return n==1?true:false;
	   }
	   
	   public String getName(String id)
	   {
	      String name=getSqlSession().selectOne("nameByMember", id);

	      return name;
	   }
	
	   //회원가입
	   
	   
	  	public List<ZipcodeDTO> getAddress(String dong)
	{
		List<ZipcodeDTO> list=getSqlSession().selectList("addressOfZipcode", dong);
		return list;
	}
	  	
	
	public void insertMember(memberDTO dto)
	{
		getSqlSession().insert("insertOfInquiry", dto);
		
	}
	
	//수정
	public memberDTO getData(String id)
	   {
	      memberDTO dto=getSqlSession().selectOne("selectOneOfMember", id);
	      return dto;
	   }
	
	  public void updateMember(memberDTO dto)
	   {
	      getSqlSession().update("UpdateOfMember", dto);
	   }
	   
}
