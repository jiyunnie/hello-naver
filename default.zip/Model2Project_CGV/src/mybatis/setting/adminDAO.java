package mybatis.setting;

import java.util.HashMap;

import org.mybatis.spring.support.SqlSessionDaoSupport;

public class adminDAO extends SqlSessionDaoSupport{
	public boolean adminLogin(String adminid,String adminpass)
	   {
	      HashMap<String, String>map=new HashMap<String, String>();
	      map.put("adminid", adminid);
	      map.put("adminpass", adminpass);
	      int n=getSqlSession().selectOne("AdminLogin", map);
	      
	      return n==1?true:false;
	   }
	

	
}
