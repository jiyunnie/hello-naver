package mybatis.setting;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;

public class noticeDAO extends SqlSessionDaoSupport {

	

		public int getTotalCount()
		{
			int n=getSqlSession().selectOne("countOfNotice");
			return n;
		}
		
		public List<noticeDTO> getlist()
		{
			
			
			List<noticeDTO> list=getSqlSession().selectList("listOfNotice");
			return list;
		}

		public List<noticeDTO> getList(int startNum,int endNum)
		{
			HashMap<String, Integer> map=new HashMap<String,Integer>();//HashMap 변수여러개를 담은후(이름, 값), map에 담김
			map.put("start", startNum); //map에 startNum변수를 담는거임
			map.put("end", endNum); //map에 endNum변수를 담는거임
			List<noticeDTO> list=getSqlSession().selectList("listOfNotice");
			return list;
		}
		
		public void insertquestion(noticeDTO dto)
		{
			getSqlSession().insert("insertOfNotice", dto);
		}
		
		
		public void updateBoard(noticeDTO dto)
		 {
			 getSqlSession().update("updateOfNotice", dto);
		 }
		
		
		public noticeDTO getData(String num)
		 {
			noticeDTO dto=getSqlSession().selectOne("onedataOfNotice", num);
			 return dto;
		 }
		
		
		public void deleteBoard(String num)
		 {
			 getSqlSession().delete("deleteOfNotice", num);
		 }
		
		
}





