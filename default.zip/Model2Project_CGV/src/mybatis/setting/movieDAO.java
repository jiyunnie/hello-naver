package mybatis.setting;

import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;

public class movieDAO extends SqlSessionDaoSupport {
	public List<movieDTO> getAllDatas()
	{
		List<movieDTO> list=getSqlSession().selectList("selectAllByMoive");
		return list;
	}
	
	public void insertmovie(movieDTO dto)
	{
		getSqlSession().insert("insertOfMovie", dto);
	}

}
