package mybatis.setting;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;


public class questionDAO extends SqlSessionDaoSupport{

	public int getTotalCount()
	{
		int n=getSqlSession().selectOne("countOfquestion");
		return n;
	}
	
	public List<questionDTO> getlist()
	{
		
		
		List<questionDTO> list=getSqlSession().selectList("listOfQuestion");
		return list;
	}

	public List<questionDTO> getList(int startNum,int endNum)
	{
		HashMap<String, Integer> map=new HashMap<String,Integer>();//HashMap 변수여러개를 담은후(이름, 값), map에 담김
		map.put("start", startNum); //map에 startNum변수를 담는거임
		map.put("end", endNum); //map에 endNum변수를 담는거임
		List<questionDTO> list=getSqlSession().selectList("listOfQuestion");
		return list;
	}

	
	public void insertquestion(questionDTO dto)
	{
		getSqlSession().insert("insertOfQuestion", dto);
	}
	
	
	public void updateBoard(questionDTO dto)
	 {
		 getSqlSession().update("updateOfQuestion", dto);
	 }
	
	
	public questionDTO getData(String num)
	 {
		 questionDTO dto=getSqlSession().selectOne("onedataOfQuestion", num);
		 return dto;
	 }
	
	
	public void deleteBoard(String num)
	 {
		 getSqlSession().delete("deleteOfQuestion", num);
	 }
	
}
